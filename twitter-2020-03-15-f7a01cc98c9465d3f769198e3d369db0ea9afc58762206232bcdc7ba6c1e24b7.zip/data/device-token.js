window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "258901",
    "token" : "qxfHBLtZl8p9HoP1XA5JZU7JKaWcYPSKFy2UbBnO",
    "createdAt" : "2020-02-27T06:52:39.658Z",
    "lastSeenAt" : "2020-03-09T05:44:01.029Z",
    "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "dmMfYScZ7IXdlCSqzxbJeLLyHnowXzReqrpjfYKZ",
    "createdAt" : "2020-03-15T07:10:36.567Z",
    "lastSeenAt" : "2020-03-15T07:10:36.570Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
} ]