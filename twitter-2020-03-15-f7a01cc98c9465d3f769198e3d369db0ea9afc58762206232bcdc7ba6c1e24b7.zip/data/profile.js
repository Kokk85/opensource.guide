window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "lázán jófej",
      "website" : "",
      "location" : "Győrújfalu, Magyarország"
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1236890878633029634/Ap2ftGcG.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1236890347529211911/1583733808"
  }
} ]