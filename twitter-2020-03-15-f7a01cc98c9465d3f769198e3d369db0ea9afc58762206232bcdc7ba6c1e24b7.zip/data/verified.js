window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "1236890347529211911",
    "verified" : false
  }
} ]