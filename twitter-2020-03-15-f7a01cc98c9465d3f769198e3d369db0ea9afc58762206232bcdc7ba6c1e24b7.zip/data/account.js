window.YTD.account.part0 = [ {
  "account" : {
    "email" : "istvan.koltai.85@freemail.hu",
    "createdVia" : "oauth:258901",
    "username" : "KoltaiIstvn3",
    "accountId" : "1236890347529211911",
    "createdAt" : "2020-03-09T05:44:00.881Z",
    "accountDisplayName" : "Koltai István"
  }
} ]