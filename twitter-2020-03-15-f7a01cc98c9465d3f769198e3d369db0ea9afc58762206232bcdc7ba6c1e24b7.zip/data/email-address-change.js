window.YTD.email_address_change.part0 = [ {
  "emailAddressChange" : {
    "accountId" : "1236890347529211911",
    "emailChange" : {
      "changedAt" : "2020-03-15T07:18:04.000Z",
      "changedFrom" : "kokk85@freemail.hu",
      "changedTo" : "istvan.koltai.85@freemail.hu"
    }
  }
} ]