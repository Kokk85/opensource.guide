window.YTD.following.part0 = [ {
  "following" : {
    "accountId" : "3375730823",
    "userLink" : "https://twitter.com/intent/user?user_id=3375730823"
  }
} ]