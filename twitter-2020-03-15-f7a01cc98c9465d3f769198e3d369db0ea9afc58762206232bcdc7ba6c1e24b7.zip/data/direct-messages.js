window.YTD.direct_messages.part0 = [ {
  "dmConversation" : {
    "conversationId" : "3375730823-1236890347529211911",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "3375730823",
        "text" : "Nézd meg: Koltai István (@KoltaiIstvn3): https://t.co/d0TlyjnyY6🤗💋",
        "mediaUrls" : [ ],
        "senderId" : "1236890347529211911",
        "id" : "1239105678838505477",
        "createdAt" : "2020-03-15T08:26:30.201Z"
      }
    } ]
  }
} ]