window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "Hungarian",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male",
        "genderOverride" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "Animation",
        "isDisabled" : false
      }, {
        "name" : "Coronavirus",
        "isDisabled" : false
      }, {
        "name" : "Hobbies and interests",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "Social Media",
        "isDisabled" : false
      }, {
        "name" : "Sports",
        "isDisabled" : false
      }, {
        "name" : "Technology",
        "isDisabled" : false
      }, {
        "name" : "Technology and computing",
        "isDisabled" : false
      }, {
        "name" : "Twitter",
        "isDisabled" : false
      }, {
        "name" : "UEFA Champions League",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "0",
        "advertisers" : [ ]
      },
      "shows" : [ ]
    },
    "locationHistory" : [ ],
    "inferredAgeInfo" : {
      "age" : [ ],
      "birthDate" : ""
    }
  }
} ]