window.YTD.direct_message_headers.part0 = [ {
  "dmConversation" : {
    "conversationId" : "3375730823-1236890347529211911",
    "messages" : [ {
      "messageCreate" : {
        "id" : "1239105678838505477",
        "senderId" : "1236890347529211911",
        "recipientId" : "3375730823",
        "createdAt" : "2020-03-15T08:26:30.201Z"
      }
    } ]
  }
} ]