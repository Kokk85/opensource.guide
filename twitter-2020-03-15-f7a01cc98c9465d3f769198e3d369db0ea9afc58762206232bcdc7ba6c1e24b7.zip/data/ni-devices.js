window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceVersion" : "8.35.0-release.03",
      "deviceType" : "Twitter for Android",
      "token" : "e6jgTBr-YoQ:APA91bG01RvNm4E4sokAMDFsZW9cSviSAuw7nX51racDGqzypUBehE2IB7YnTVyE5kBPSv_YElzvHcCWV-rXJsIgjYGmGHvxlpEaL1ecuxXgI5DAug-2NhTdwqzpnFBKRFFr7tB-RwgU",
      "updatedDate" : "2020.03.15",
      "createdDate" : "2020.03.15"
    }
  }
}, {
  "niDeviceResponse" : {
    "pushDevice" : {
      "deviceType" : "Twitter for Web",
      "createdDate" : "2020.03.15",
      "updatedDate" : "2020.03.15",
      "token" : "https://fcm.googleapis.com/fcm/send/fM6TBIrRwnI:APA91bFnWW2V1UMPlJYQbA_56IQnfhbGCw-WFYaA08Afeh2yZKwARu0Hga423Po7nAhxGa_06yXwdSHCWYcxSEODy5DSGbu8pWGMN9Eto7dOvRdhSHtTucLac6eMI1O-LVqkfE6Fg4WS"
    }
  }
} ]